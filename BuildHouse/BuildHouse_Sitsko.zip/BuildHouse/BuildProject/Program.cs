﻿using System;
using BuildLibrary.BuildElems;
using BuildLibrary.TeamBuilders;

namespace BuildProject
{
    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
