﻿using BuildLibrary.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BuildLibrary.BuildElems
{
    internal class Roof : IPart
    {
        public bool IsCreated(int value)
        {
            throw new NotImplementedException();
        }

        public int Remained(int value)
        {
            throw new NotImplementedException();
        }
    }
}
